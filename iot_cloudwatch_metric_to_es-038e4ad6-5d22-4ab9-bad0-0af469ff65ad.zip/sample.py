import boto3
import re
import requests
import gzip
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth
import base64
import requests,sys,json
from botocore.exceptions import ClientError

region = 'cn-north-1'
service = 'es'
credentials = boto3.Session().get_credentials()
#awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
host = 'https://search-aod-iot-security-project-lmp6z2lhp7tjil4v5nbia3monm.cn-north-1.es.amazonaws.com.cn' # the OpenSearch Service domain, including https://
index = 'iot-metric-cloudwatch-index'
type = '_doc'
url = host + '/' + index + '/' + type
headers = { "Content-Type": "application/json" }

s3 = boto3.resource('s3')

def get_secret():

    secret_name = "arn:aws-cn:secretsmanager:cn-north-1:502454306654:secret:ES_Kibana_credential-kPJOir"
    region_name = "cn-north-1"


    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:

        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            
    return secret
        
# Lambda execution starts here
def handler(event, context):

    secret_demo = get_secret()
    secret_demo_json = json.loads (secret_demo)
    
    account = secret_demo_json['es_account']                                               
    pwd = secret_demo_json['es_pwd']
    
    for record in event['Records']:
        message = record['Sns']
        print(message)
        document = {"message": message }
        print(document)
        r = requests.post(url, auth=HTTPBasicAuth(account, pwd), json=document, headers=headers)
        print(r)
    return event