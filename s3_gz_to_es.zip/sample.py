import boto3
import re
import requests
import gzip
from requests_aws4auth import AWS4Auth
from requests.auth import HTTPBasicAuth

region = 'cn-north-1'
service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
print (credentials)
print (credentials.access_key)
print (credentials.secret_key)
host = 'https://search-aod-iot-security-project-lmp6z2lhp7tjil4v5nbia3monm.cn-north-1.es.amazonaws.com.cn' # the OpenSearch Service domain, including https://
index = 'lambda-s3-index'
type = '_doc'
account = 'demoyy'
pwd = 'Y@ng123456'
url = host + '/' + index + '/' + type

headers = { "Content-Type": "application/json" }

s3 = boto3.resource('s3')

# Regular expressions used to parse some simple log lines
#ip_pattern = re.compile('(\d+\.\d+\.\d+\.\d+)')
#time_pattern = re.compile('\[(\d+\/\w\w\w\/\d\d\d\d:\d\d:\d\d:\d\d\s-\d\d\d\d)\]')
#message_pattern = re.complie('\{(.+)\}')
message_pattern = re.compile('\{(.+)\}')

def read_gz_file(file):
     with gzip.open(file, 'r') as pf:
         for line in pf:
             yield line
        
# Lambda execution starts here
def handler(event, context):
    for record in event['Records']:
        print(record)
        # Get the bucket name and key for the new file
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        print (bucket)
        # Get, read, and split the file into lines
        #obj = s3.get_object(Bucket=bucket, Key=key)
        s3.Bucket(bucket).download_file(key, '/tmp/log.gz')
        
        #body = obj['Body'].read()
        #lines = body.splitlines()
        con = read_gz_file(r'/tmp/log.gz')
        if getattr(con, '__iter__', None):
            for line in con:
                line = line.decode("utf-8")
                message = message_pattern.search(line).group(1)
                document = {"message": message }
                print(document)
                r = requests.post(url, auth=HTTPBasicAuth(account, pwd), json=document, headers=headers)
                print(r)
    return event